#include <LED.h>

LED::LED() {}

void LED::setState(LED_STATE state) {}

void LED::toggleState() {}

bool LED::isOn() const {
  return on;
} 
