#include "../include/LED.h"

LED::LED() {}

void LED::setState(LED_STATE) {}

bool LED::isOn() const {
  return on;
} 
