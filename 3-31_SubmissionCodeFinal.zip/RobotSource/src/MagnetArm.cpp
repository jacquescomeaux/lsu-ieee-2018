#include "../include/MagnetArm.h"

void MagnetArm::goToHeight(float h) const {}

void MagnetArm::magnetize() const {}

void MagnetArm::demagnetize() const {}

void MagnetArm::storeTokens() const {}

MagnetArm::MagnetArm() {}

void MagnetArm::reset() const {}

void MagnetArm::pickUpToken() const {}

void MagnetArm::dropTokens() const {}
