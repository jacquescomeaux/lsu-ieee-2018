#include "../include/RGBSensor.h"

RGBSensor::RGBSensor() {}

Color RGBSensor::getColor() const {return Color::NONE;}
