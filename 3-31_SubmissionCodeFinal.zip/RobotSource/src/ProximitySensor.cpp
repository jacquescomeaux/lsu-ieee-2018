#include "../include/ProximitySensor.h"

ProximitySensor::ProximitySensor() {}

float ProximitySensor::getDistance() const {return 0;}
