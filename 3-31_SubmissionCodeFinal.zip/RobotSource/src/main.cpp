#include "../include/Board.h"
#include "../include/Robot.h"

int main() {
  const Board platform;
  const SortBot sorty;
  sorty.control.runAlgorithm();
  return 0;
}
