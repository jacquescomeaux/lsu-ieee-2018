#include "../include/SensorRing.h"

SensorRing::SensorRing() {}

bool SensorRing::onLine() const { return true; }

bool SensorRing::atIntersection() const { return true; }
