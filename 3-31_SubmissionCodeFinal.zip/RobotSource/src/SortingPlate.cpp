#include "../include/SortingPlate.h"

SortingPlate::SortingPlate() {}

void SortingPlate::reset() {}

void SortingPlate::moveToPosition(float p) {}

float SortingPlate::getPosition() const {return 0;}
