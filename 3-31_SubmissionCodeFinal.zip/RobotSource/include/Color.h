#ifndef COLOR_H
#define COLOR_H

enum class Color {
  NONE,
  RED,
  GREEN,
  BLUE,
  CYAN,
  MAGENTA,
  YELLOW,
  WHITE,
  GRAY,
  BLACK
};

#endif
