#ifndef WHEEL_H
#define WHEEL_H

#include "SerialLink.h"

class Wheel : private SerialLink {
  public:
    Wheel();
};

#endif//WHEEL_H
